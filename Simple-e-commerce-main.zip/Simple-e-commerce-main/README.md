# Simple-e-commerce
Repositori ini dibuat untuk memenuhi tugas bootcamp IIT path back end. 

Daftar routes: 
- /products
- /add_to_cart
- /cart
- /remove_from_cart
- /buy
